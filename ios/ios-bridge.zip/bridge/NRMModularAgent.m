#import "NRMModularAgent.h"
#import <NewRelic_Mobile_iOS/NewRelic.h>
#import <NewRelic_Mobile_iOS/NRMAStackTrace.h>

@interface NewRelic (Private)
    + (bool) isAgentStarted:(SEL _Nonnull)callingMethod;
@end

@implementation NRMModularAgent

-(id)init {
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        [NewRelic startAgent];
    });
    return self;
}

+ (BOOL)requiresMainQueueSetup{
    return NO;
}

- (dispatch_queue_t)methodQueue{
    return dispatch_get_main_queue();
}

RCT_EXPORT_MODULE()

// Refer to https://facebook.github.io/react-native/docs/native-modules-ios for a list of supported argument types

RCT_REMAP_METHOD(startAgent,
                 startWithResolver:(RCTPromiseResolveBlock)resolve
                 rejecter:(RCTPromiseRejectBlock)reject){
    NSLog(@"NRMA calling start agent for RN bridge is deprecated. The agent automatically starts on creation.");
    resolve(@(TRUE));
}

RCT_EXPORT_METHOD(isAgentStarted:(NSString* _Nonnull)call
                   callback: (RCTResponseSenderBlock)callback){
    callback(@[[NSNull null],  @([NewRelic isAgentStarted:NSSelectorFromString(call)])]);
}

RCT_EXPORT_METHOD(recordBreadcrumb:(NSString* _Nonnull)eventName attributes:(NSDictionary* _Nullable)attributes) {
    [NewRelic recordBreadcrumb:eventName attributes:attributes];
}

RCT_EXPORT_METHOD(setStringAttribute:(NSString* _Nonnull)key withString:(NSString* _Nonnull)value) {
    [NewRelic setAttribute:key withString:value];
}

RCT_EXPORT_METHOD(setNumberAttribute:(NSString* _Nonnull)key withNumber:( NSNumber* _Nonnull)value) {
    [NewRelic setAttribute:key withNumber:value];
}

RCT_EXPORT_METHOD(setBoolAttribute:(NSString* _Nonnull)key withBool:(BOOL)value) {
    [NewRelic setAttribute:key withBool:value];
}

RCT_EXPORT_METHOD(setUserId:(NSString* _Nonnull)userId) {
    [NewRelic setUserId:userId];
}

RCT_EXPORT_METHOD(continueSession) {
    [NewRelic continueSession];
}

RCT_EXPORT_METHOD(setJSAppVersion:(NSString* _Nonnull)version) {
    [NewRelic setAttribute:@"JSAppVersion" withString:version];
}

RCT_EXPORT_METHOD(recordCustomEvent:(NSString* _Nonnull) eventType eventName:(NSString* _Nullable)eventName eventAttributes:(NSDictionary* _Nullable)attributes) {
    // todo: Not sure if we need to check the validity of these arguments at all..
    [NewRelic recordCustomEvent:eventType eventName:eventName attributes:attributes];
}

RCT_EXPORT_METHOD(recordStack:(NSString* _Nullable) errorName
                  errorMessage:(NSString* _Nullable)errorMessage
                  errorStack:(NSString* _Nullable)errorStack
                  isFatal:(NSNumber* _Nonnull)isFatal
                  jsAppVersion:(NSString* _Nullable)jsAppVersion) {
    NRMAStackTrace* trace = [[NRMAStackTrace alloc] init];
    trace.buildId = jsAppVersion;
    trace.fatal = isFatal;
    trace.stackType = ReactNative;
    NRMAStackException* message = [NRMAStackException messageWithName:errorName reason:errorMessage];
    trace.message  = message;
    NRMAStack* stack = [[NRMAStack alloc] init];
    stack.identifier = @"JS Thread";
    stack.isThrowingThread = @YES;
    NSArray* stackArray = [errorStack componentsSeparatedByString:@"\n"];
    for (NSString* frameString in stackArray){
        NRMAStackFrame* frame = [[NRMAStackFrame alloc] init];
        frame.sourceLine = frameString;
        [stack.stackFrames addObject:frame];
    }

    trace.occurrenceId = [NSUUID new].UUIDString;

    [trace.stacks addObject:stack];

    [NewRelic recordStack:trace];
}

@end

