#import <React/RCTBridgeModule.h>

@interface NRMModularAgent : NSObject <RCTBridgeModule>

@end
  
